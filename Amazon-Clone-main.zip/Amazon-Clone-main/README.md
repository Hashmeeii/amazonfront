Amazon clone
only front end
Good for basics in web developing
HTML and CSS project
